# DUMP
NOW YOU CAN EASILY MAKE FILE WITHOUT ANY ISSUE  USE COOKIES FOR LOGIN   REMEMBER ME IN YOUR PRAYERS🙏
  - `rm -rf DUMP`
  - `git clone https://github.com/Hamii-king-06/DUMP.git`
  - `cd DUMP`
  - `python EXTRACT`
